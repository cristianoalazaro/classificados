# classificados-mvc-php
Sistema simples de anuncios utilizando o padrão mvc com PHP

Criação de um sistema de classificados, com usuário e senha, utilizando o padrão MVC com Orientação a Objetos e linguagem PHP. Esse sistema foi feito com base no curso da B7Web, do professor Bonieky Lacerda, e tendo como base as aulas de MVC.

Utilizando o Autoload do Composer (Antes não estava)

O arquivo com o dump do banco de dados também segue no repositório.

OBS: Se mudar o nome do diretório do projeto, mudar também sua referência no arquivo .htaccess e no arquivo config.php. 

OBS 2: Conferir se suas credenciais são as mesmas no arquivo config.php. Estou usando usuário "root" e sem senha.

OBS 3: Nos arquivos está sendo utilizado Bootstrap.  

BOM USO !

Qualquer dúvida só me chamar por email. Se eu puder, ajudarei com certeza.
